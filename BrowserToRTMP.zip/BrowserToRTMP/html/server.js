
// Adapted from - https://github.com/fbsamples/Canvas-Streaming-Example
var fs = require('fs');
const child_process = require('child_process'); // To be used later for running FFmpeg
const express = require('express');
const http = require('http');
const https = require('https');
const WebSocketServer = require('ws').Server;
var wsservers = [];
var wss;
const serveropt = {
	key: fs.readFileSync('/usr/local/nginx/ssl/private.key'),
	cert: fs.readFileSync('/usr/local/nginx/ssl/certificate.crt'),
};
const ports = [60001, 60002, 60003];
const app = express();
var servers = [];
var s;
var streamNo;
//var wstreams = [];
var wstream,wstream1,wstream2;
//var ffmpegScreen = require('child_process').exec;
var silencePipe1;

// Serve static files out of the www directory, where we will put our HTML page
// Can specify via dirname or absolute path
//app.use(express.static(__dirname, {index: '_'}));
// Disable index file by putting non-existing path - https://stackoverflow.com/a/25167332/3016570
// Set index file to translate.html
app.use(express.static('/usr/local/nginx/html/', {index: '_'}));
app.get('/', function(req, res) {
    res.sendFile('/usr/local/nginx/html/translate.html');
});

// Setup for all ports - https://stackoverflow.com/questions/19296797/running-node-js-http-server-on-multiple-ports
ports.forEach(function(port) {
    s = https.createServer(serveropt, app);
    s.listen(port);
    servers.push(s);
    console.log('Listening on ' + port);
    wss = new WebSocketServer({server: s});
    wsservers.push(wss);
//    var streamId = port - 60000;
//    wstream = fs.createWriteStream('./../scripts/tmp/nodeToFfmpegPipe' + streamId);
//    wstreams.push(wstream);
});

// Multiple servers in single loop. Streams tend to end when there is more than one stream.
/*wsservers.forEach(function(wss) {
	wss.on('connection', (ws, req) => {
		streamId = req.socket.localPort - 60000;
		streamNo = 'stream' + streamId;
		console.log('Use for stream: ' + streamNo);
		// Piping to a named file - https://github.com/nodejs/help/issues/719#issuecomment-314004719
//                wstream = fs.createWriteStream('./../scripts/tmp/nodeToFfmpegPipe' + streamId);
		ws.on('message', (msg) => {
			console.log('DATA', msg);
//			ffmpeg.stdin.write(msg);
//			console.log(wstreams[streamId - 1]);
			wstreams[streamId - 1].write(msg);
		});
		// https://stackoverflow.com/a/22056840/3016570
//		screenCommand = 'screen -dmS ' + streamNo + ' bash -c "ls -l; exec bash;"';
//		screenCommand = 'screen -dmS ' + streamNo + ' bash -c "ffmpeg -i /usr/local/nginx/html/nodeToFfmpeg' + streamNo + ' -vcodec libx264 -preset superfast -b:v 500k -r 25 -s 640x360 -acodec aac -b:a 128k -ac 1 -f flv rtmp:\/\/127.0.0.1\/translate\/' + streamNo + ';exec bash;"';
//		ffmpegScreen(screenCommand, function(error, stdout, stderr){
//			console.log('Screen generated');
//			console.log('stdout:', stdout);
//			console.log('stderr:',stderr);
//		});
	});
});
*/

	wsservers[0].on('connection', (ws, req) => {
		var streamId = req.socket.localPort - 60000;
		streamNo = 'stream' + streamId;
		console.log('Use for stream: ' + streamNo);
		// Piping to a named file - https://github.com/nodejs/help/issues/719#issuecomment-314004719
                wstream1 = fs.createWriteStream('/usr/local/nginx/scripts/tmp/nodeToFfmpegPipe' + streamId);
		ws.on('message', (msg) => {
			//console.log('DATA', msg);
//			ffmpeg.stdin.write(msg);
			if (typeof silencePipe1 !== 'undefined') {
				silencePipe1.kill('SIGINT');
				console.log('Killing SIlence Pipe 1');
			}
			wstream1.write(msg);
		});
		// Handle errors in write stream - https://stackoverflow.com/a/43303770/3016570
		wstream1.on('error', function(err) {
			console.log(err);
			wstream1.close();
		});
		// If the socket errors out, stop writing to pipe.
		ws.on('error', (e) => {
			console.log('Error: ', e.message);
			wstream1.close();
		});
		// If the client disconnects, stop writing to pipe.
		ws.on('close', (e) => {
			console.log('Websocket closed: ', e.reason);
			wstream1.end();
			wstream1.on('close', function() {console.log('wstream1 closed');});

		silencePipe1 = child_process.spawn('ffmpeg', [
		//'-nostdin', '-f', 'flv', '-i', 'rtmp:\/\/127.0.0.1\/translate\/source', 
					'-f', 'lavfi', '-i', 'anullsrc', '-vn', '-acodec', 'aac', '-b:a', '96k', '-ac', '1', 
					'-vbsf', 'h264_mp4toannexb', '-f', 'mpegts', 'pipe:1'
	//				'-f', 'flv',  'rtmp:\/\/127.0.0.1/translate/stream1'
		]);
		silencePipe1.stdout.read('/usr/local/nginx/scripts/tmp/nodeToFfmpeg1');

			// Handle STDIN pipe errors by logging to the console.
			// These errors most commonly occur when FFmpeg closes and there is still
			// data to write.  If left unhandled, the server will crash.
			silencePipe1.stdin.on('error', (e) => {
			    console.log('FFmpeg STDIN Error', e);
			});

			// FFmpeg outputs all of its messages to STDERR.  Let's log them to the console.
			silencePipe1.stderr.on('data', (data) => {
			    console.log('FFmpeg STDERR:', data.toString());
			});

		});
		wstream1.on('end', function () {
		});

		// https://stackoverflow.com/a/22056840/3016570
//		screenCommand = 'screen -dmS ' + streamNo + ' bash -c "ls -l; exec bash;"';
//		screenCommand = 'screen -dmS ' + streamNo + ' bash -c "ffmpeg -i /usr/local/nginx/html/nodeToFfmpeg' + streamNo + ' -vcodec libx264 -preset superfast -b:v 500k -r 25 -s 640x360 -acodec aac -b:a 128k -ac 1 -f flv rtmp:\/\/127.0.0.1\/translate\/' + streamNo + ';exec bash;"';
//		ffmpegScreen(screenCommand, function(error, stdout, stderr){
//			console.log('Screen generated');
//			console.log('stdout:', stdout);
//			console.log('stderr:',stderr);
//		});
	});
//});

//wsservers.forEach(function(wss) {
	wsservers[1].on('connection', (ws, req) => {
		var streamId = req.socket.localPort - 60000;
		streamNo = 'stream' + streamId;
		console.log('Use for stream: ' + streamNo);
		// Piping to a named file - https://github.com/nodejs/help/issues/719#issuecomment-314004719
                wstream2 = fs.createWriteStream('/usr/local/nginx/scripts/tmp/nodeToFfmpegPipe' + streamId);
		ws.on('message', (msg) => {
//			console.log('DATA', msg);
//			ffmpeg.stdin.write(msg);
			wstream2.write(msg);
		});
		// https://stackoverflow.com/a/22056840/3016570
//		screenCommand = 'screen -dmS ' + streamNo + ' bash -c "ls -l; exec bash;"';
//		screenCommand = 'screen -dmS ' + streamNo + ' bash -c "ffmpeg -i /usr/local/nginx/html/nodeToFfmpeg' + streamNo + ' -vcodec libx264 -preset superfast -b:v 500k -r 25 -s 640x360 -acodec aac -b:a 128k -ac 1 -f flv rtmp:\/\/127.0.0.1\/translate\/' + streamNo + ';exec bash;"';
//		ffmpegScreen(screenCommand, function(error, stdout, stderr){
//			console.log('Screen generated');
//			console.log('stdout:', stdout);
//			console.log('stderr:',stderr);
//		});
	});
//});


// Below is set up for a single server instance
/*const server = https.createServer(serveropt, app).listen(60000, () => {
  console.log('Listening...');
});

// Serve static files out of the www directory, where we will put our HTML page
//app.use(express.static(__dirname + '/../../Browsermic'));
app.use(express.static(__dirname));

const wss = new WebSocketServer({
  server: server
});

wss.on('connection', (ws, req) => {
  console.log('Inside socket');

  const fullUrl = decodeURIComponent(req.url);
  const streamNo = fullUrl.substr(fullUrl.indexOf("?") + 1);
  var rtmpUrl = 'rtmp:\/\/127.0.0.1\/translate\/' + streamNo;
  console.log('Target RTMP Stream:', rtmpUrl);

  // Launch FFmpeg to handle all appropriate transcoding, muxing, and RTMP.
  // If 'ffmpeg' isn't in your path, specify the full path to the ffmpeg binary.
  const ffmpeg = child_process.spawn('ffmpeg', [
    // Facebook requires an audio track, so we create a silent one here.
    // Remove this line, as well as `-shortest`, if you send audio from the browser.
 //   '-f', 'lavfi', '-i', 'anullsrc',

    // FFmpeg will read input video from STDIN
    '-i', '-',
    // Uncomment below to use a file in Windows    
 //     '-i', 'C:\\Users\\User\\Desktop\\file.mp4', 
    // Because we're using a generated audio source which never ends,
    // specify that we'll stop at end of other input.  Remove this line if you
    // send audio from the browser.
//    '-shortest',
    
    // If we're encoding H.264 in-browser, we can set the video codec to 'copy'
    // so that we don't waste any CPU and quality with unnecessary transcoding.
    // If the browser doesn't support H.264, set the video codec to 'libx264'
    // or similar to transcode it to H.264 here on the server.
    '-vcodec', 'libx264', '-s', '640x360', '-preset', 'superfast', '-b:v', '500k', '-r', '25', 
    
    // AAC audio is required for Facebook Live.  No browser currently supports
    // encoding AAC, so we must transcode the audio to AAC here on the server.
    '-acodec', 'aac', '-b:a', '128k', '-ac', '1',
    
    // FLV is the container format used in conjunction with RTMP
    '-f', 'flv',
    
    // The output RTMP URL.
    // For debugging, you could set this to a filename like 'test.flv', and play
    // the resulting file with VLC.  Please also read the security considerations
    // later on in this tutorial.
    rtmpUrl
//     'rtmp:\/\/127.0.0.1\/translate\/stream2'
    // Uncomment below to output to a file
//	'output.mp4' 
  ]);
  
  // If FFmpeg stops for any reason, close the WebSocket connection.
  ffmpeg.on('close', (code, signal) => {
    console.log('FFmpeg child process closed, code ' + code + ', signal ' + signal);
    ws.terminate();
  });
  
  // Handle STDIN pipe errors by logging to the console.
  // These errors most commonly occur when FFmpeg closes and there is still
  // data to write.  If left unhandled, the server will crash.
  ffmpeg.stdin.on('error', (e) => {
//    console.log('FFmpeg STDIN Error', e);
  });
  
  // FFmpeg outputs all of its messages to STDERR.  Let's log them to the console.
  ffmpeg.stderr.on('data', (data) => {
//    console.log('FFmpeg STDERR:', data.toString());
  });

  // When data comes in from the WebSocket, write it to FFmpeg's STDIN.
  ws.on('message', (msg) => {
  console.log('DATA', msg);
    ffmpeg.stdin.write(msg);
  });
  
  // If the client disconnects, stop FFmpeg.
  ws.on('close', (e) => {
    ffmpeg.kill('SIGINT');
  });
  
});
*/
