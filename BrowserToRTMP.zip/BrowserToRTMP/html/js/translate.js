//Use Chrome or Edge
// Basic Intro - https://www.html5rocks.com/en/tutorials/getusermedia/intro/
// Browsers allow access to webcam and mic only over https connections. 
// Register the server with a certificate. 
// For testing purposes, go to chrome://flags/#unsafely-treat-insecure-origin-as-secure in your browser and add the site to the whitelist.
// See https://sites.google.com/a/chromium.org/dev/Home/chromium-security/deprecating-powerful-features-on-insecure-origins

//Set up handle to mic
const video = document.querySelector("video");
const mic = document.querySelector('.mic-icon');

// Only audio is needed
/*  const constraints = { audio: true, video: {
  				      "mandatory": {
					   "maxWidth": 640,
					   "maxHeight": 360,
					   "maxFrameRate": 30
					  	         },
				       "optional": []
					 }
	};
*/
//  const constraints = { audio: true, video: true, };
  const constraints = { audio: true, video: false, };
// High quality opus codec is used, so bitrate is sufficient

  const options = {
			audioBitsPerSecond: 128000,
//			videoBitsPerSecond: 250000,
//			mimeType: 'audio/webm;codecs=opus',
			mimeType: 'audio/webm;codecs=opus'
}

// For onSuccess method -  https://stackoverflow.com/questions/46648645/navigator-mediadevices-enumeratedevices-not-display-device-label-on-firefox
// Check if Browser supports using webcam and mic
if (navigator.mediaDevices.getUserMedia) {
  console.log('getUserMedia supported.');

  let chunks = [];

	// Once we get User Media, start processing
  let onSuccess = function(stream) {
//    video.srcObject = stream;

	// Create a mediastream with the options defined above
	const mediaRecorder = new MediaRecorder(stream,options);

	// Function to handle mic on & mute, plus icon change in html, & mediaRecorder state change	
    mic.onclick = function() {
	  if (mediaRecorder.state != "recording") {
		mediaRecorder.start(1000);
		console.log(mediaRecorder.state);
		console.log("recorder started");
		mic.innerHTML = "mic";
//      record.disabled = true;
	  } else {
		mediaRecorder.stop();
		console.log(mediaRecorder.state);
		console.log("recorder stopped");
		mic.innerHTML = "mic_off";
	  }
	} 

	// Setup websockets - https://github.com/fbsamples/Canvas-Streaming-Example
	const ws = new WebSocket(
	
	// Replace https & https to ws & wss protocol http: -> ws:, https: -> wss:
	window.location.href.replace('http', 'ws'));

	ws.addEventListener('open', (e) => {
		console.log('WebSocket Open', e);
		console.log('URL', window.location.href);
		console.log(mediaRecorder.mimeType);

		// When data is available, send data over the websocket
		mediaRecorder.addEventListener('dataavailable', (e) => {
			ws.send(e.data);
		//	console.log(e.data);
		});
		mediaRecorder.addEventListener('stop', ws.close.bind(ws));
		mediaRecorder.start(1000);
		console.log(mediaRecorder.state);
	});

	ws.addEventListener('close', (e) => {
		console.log('WebSocket Close', e);
		mediaRecorder.stop();
	});	
	
// ondataavailable method - https://developer.mozilla.org/en-US/docs/Web/API/MediaRecorder/ondataavailable
//	mediaRecorder.ondataavailable  = function(e) {
//		chunks.pop();
//		chunks.push(e.data);
//		console.log(chunks);
//   var blob = new Blob(chunks, { 'type' : 'video/x-matroska;codecs=avc1,opus' });
//    var videoURL = window.URL.createObjectURL(blob);
//    video.src = videoURL;
//    console.log("playing a chunk");
//    }
  }
  let onError = function (err) {
                console.log('The following error occured: ' + err);
            }

  navigator.mediaDevices.getUserMedia(constraints).then(onSuccess, onError);

} else {
            console.log('getUserMedia not supported on your browser!');
}

