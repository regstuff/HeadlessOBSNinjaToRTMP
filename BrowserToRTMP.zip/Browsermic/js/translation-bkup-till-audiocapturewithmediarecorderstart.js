// Basic Intro - https://www.html5rocks.com/en/tutorials/getusermedia/intro/
const constraints = {
  video: true,
  audio: true,
};

const video = document.querySelector("video");
const mic = document.querySelector('.mic-icon');

//For onSuccess method -  https://stackoverflow.com/questions/46648645/navigator-mediadevices-enumeratedevices-not-display-device-label-on-firefox
if (navigator.mediaDevices.getUserMedia) {
  console.log('getUserMedia supported.');

  const constraints = { audio: true, video: true, };
  let chunks = [];

  let onSuccess = function(stream) {
//    video.srcObject = stream;
		const options = {
			audioBitsPerSecond: 128000,
			videoBitsPerSecond: 2500000,
			mimeType: 'video/webm;codecs=h264,opus'
		}
		
    const mediaRecorder = new MediaRecorder(stream,options);
	console.log(mediaRecorder.mimeType);
	mediaRecorder.start(1000);
	console.log(mediaRecorder.state);
	
    mic.onclick = function() {
	  if (mediaRecorder.state != "recording") {
		mediaRecorder.start(1000);
		console.log(mediaRecorder.state);
		console.log("recorder started");
		mic.innerHTML = "mic";
//      record.disabled = true;
	  } else {
		mediaRecorder.stop();
		console.log(mediaRecorder.state);
		console.log("recorder stopped");
		mic.innerHTML = "mic_off";
	  }
	}  
// ondataavailable method - https://developer.mozilla.org/en-US/docs/Web/API/MediaRecorder/ondataavailable
	mediaRecorder.ondataavailable  = function(e) {
		chunks.pop();
		chunks.push(e.data);
		console.log(chunks);
    var blob = new Blob(chunks, { 'type' : 'video/x-matroska;codecs=avc1,opus' });
    var videoURL = window.URL.createObjectURL(blob);
    video.src = videoURL;
    console.log("playing a chunk");
    }
  }
  let onError = function (err) {
                console.log('The following error occured: ' + err);
            }
			
  navigator.mediaDevices.getUserMedia(constraints).then(onSuccess, onError);

} else {
            console.log('getUserMedia not supported on your browser!');
}

const ws = new WebSocket(
window.location.protocol.replace('http', 'ws') + '//' + // http: -> ws:, https: -> wss:
window.location.host + 
  '/rtmp/akjkajk'
);

ws.addEventListener('open', (e) => {
  console.log('WebSocket Open', e);
});

ws.addEventListener('close', (e) => {
  console.log('WebSocket Close', e);
});